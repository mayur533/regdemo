package com.example.regidemo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    private final String Message;

    public MainActivity(String message) {
        Message = message;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void register(View view) {
        EditText mail=(EditText) findViewById(R.id.txtmail);
        EditText pass=(EditText) findViewById(R.id.txtpass);
        String m=mail.getText().toString();
        String p=pass.getText().toString();
        SharedPreferences sp=getSharedPreferences(Message,MODE_PRIVATE);
        SharedPreferences.Editor ed=sp.edit();
        ed.putString("mail",m);
        ed.putString("pass",p);
        ed.apply();
        Intent  intent=new Intent(getApplicationContext(),ViewData.class);
        startActivity(intent);






    }
}