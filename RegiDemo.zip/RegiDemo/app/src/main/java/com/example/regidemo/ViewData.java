package com.example.regidemo;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ViewData extends AppCompatActivity {
    private final String Message;

    public ViewData(String message) {
        Message = message;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewdata);
        SharedPreferences sp=getSharedPreferences(Message,MODE_PRIVATE);
        String email=sp.getString("mail","");
        String password=sp.getString("pass","");
        TextView t1=(TextView) findViewById(R.id.ml);
        TextView t2=(TextView) findViewById(R.id.ps);
        t1.setText(email);
        t2.setText(password);

    }

}
